#!/bin/sh
#
# Shell-script d'installation de PolyTeX pour UNIX/teTeX
#
# S. Mottelet, le 5/5/2000

if test -z $TEXMF;
   then echo -e  "Chemin du r�pertoire texmf de votre distribution teTeX :\c "
   read TEXMF
   if ! test -f $TEXMF/tex/latex/config/texsys.cfg;
      then echo $TEXMF ": ce chemin est invalide !"
      exit 1;
   fi
fi

if test ! -w $TEXMF;
      then echo "Vous n'avez pas l'autorisation d'�criture dans $TEXMF"
      echo "Contactez votre administrateur syst�me"
      exit 1;
fi

cd ../test
echo -e  "Test de l'installation de teTeX : \c"

if latex < exemple.tex > /dev/null; 
     then echo 'OK'
     cd ../unix
else
     echo  'ECHEC'
     cd ../unix
     echo "Votre installation de teTeX semble d�fecteuse"
     echo "Je n'arrive pas � compiler le fichier de test." 
     echo "R�installez une version plus r�cente de teTeX."
     exit 1;    
fi

echo -e  "Supression des anciens fichiers : \c"   
if test -d  $TEXMF/tex/latex/polytex;
   then rm -rf $TEXMF/tex/latex/polytex
fi
if test -d  $TEXMF/tex/latex/polytexbeta;
   then rm -rf $TEXMF/tex/latex/polytexbeta
fi
echo "OK"

echo -e  "Installation des fichiers de style PolyTeX 2.5: \c"
cp -rf ../texmf/tex/latex/polytex $TEXMF/tex/latex
cp -f ../texmf/makeindex/*.ist $TEXMF/makeindex
cp -f ../texmf/tex/latex/misc/* $TEXMF/tex/latex/misc
echo  "OK"
echo -e  "Repertoire d'installation des fichiers de commande [/usr/local/bin] : \c"
read POLYBIN
if test -z "$POLYBIN";
   then POLYBIN=/usr/local/bin
fi
echo -e  "Installation des commandes dans $POLYBIN : \c"
if test ! -w /usr/local/bin;
      then echo "ECHEC" 
      echo "Vous n'avez pas l'autorisation d'�criture dans $POLYBIN"
      echo "Contactez votre administrateur syst�me"
      exit 1;
else
   cp -f bin/* /usr/local/bin
   echo  "OK"
fi
echo -e  "Mise � jour de la base de donn�es des fichiers de teTeX : \c"
mktexlsr
echo  "OK"
