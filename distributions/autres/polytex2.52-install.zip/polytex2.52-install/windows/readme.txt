Pour installer PolyTeX, il suffit de 

1 - �diter le fichier
install.bat pour modifier sur la troisi�me ligne le
chemin du repertoire de votre distribution 
MikTeX. (en g�n�ral c:\texmf pour MikTeX < 2.0 et 
c:\Program Files\MiKTeX pour MikTeX >= 2.0)

Si vous avez installe WinEdt, veuillez
modifier aussi le chemin correspondant. Cela permettra
au programme d'installation d'ajouter le menu "PolyTeX".

2 - executer le fichier install.bat

Ce fichier de commandes copie les fichiers de style
PolyTeX ainsi que ceux d'autres packages n�cessaires
mais non fournis par la distribution MikTeX.
