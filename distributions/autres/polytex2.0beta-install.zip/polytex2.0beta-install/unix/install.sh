#!/bin/sh
#
# Shell-script d'installation de PolyTeX pour UNIX/teTeX
#
# S. Mottelet, le 5/5/2000

if test -z $TEXMF;
   then echo -e  "Chemin du r�pertoire texmf de votre distribution teTeX :\c "
   read TEXMF
   if ! test -f $TEXMF/tex/latex/config/texsys.cfg;
      then echo $TEXMF ": ce chemin est invalide !"
      exit 1;
   fi
fi
   if test ! -w $TEXMF;
      then echo "Vous n'avez pas l'autorisation d'�criture dans $TEXMF"
      echo "Contactez votre administrateur syst�me"
      exit 1;
   fi
   if test ! -d $TEXMF/tex/french;
      then if test ! -d $TEXMF/tex/generic/french;
         then cp -rf ../texmf/tex/generic/french $TEXMF/tex/generic;\
	 echo -e "Installation du package French"
         mktexlsr > /dev/null
      fi        
   fi
   cd ../test
   echo -e  "Test de l'installation de teTeX : \c"
   if latex < exemple.tex > /dev/null; 
     then echo 'OK'
     cd ../unix
   else
     echo  'ECHEC'
     cd ../unix
     echo -e "Mise � jour de hyperref 6.66m : \c"
     cp -rf ../texmf/tex/latex/hyperref $TEXMF/tex/latex
     mktexlsr > /dev/null
     echo  "OK"
     echo -e "Nouveau test de  l'installation teTeX : \c"
     cd ../test
     if latex < exemple.tex > /dev/null;
        then echo  "OK"
	cd ../unix
     else
        echo  'ECHEC'
        cd ../unix
        echo "Votre installation de teTeX semble d�fecteuse"
        echo "Je n'arrive pas � compiler le fichier de test." 
        echo "R�installez une version plus r�cente de teTeX."
	exit 1;
     fi    
   fi

echo -e  "Installation des fichiers de style PolyTeX 1.5: \c"
cp -rf ../texmf/tex/latex/polytex $TEXMF/tex/latex
echo  "OK"
echo -e  "Installation des fichiers de style PolyTeX 2.0beta: \c"
cp -rf ../texmf/tex/latex/polytexbeta $TEXMF/tex/latex
cp -f ../texmf/makeindex/*.ist $TEXMF/makeindex
echo  "OK"
echo -e  "Repertoire d'installation des fichiers de commande [/usr/local/bin] : \c"
read POLYBIN
if test -z "$POLYBIN";
   then POLYBIN=/usr/local/bin
fi
echo -e  "Installation des commandes dans $POLYBIN : \c"
if test ! -w /usr/local/bin;
      then echo "ECHEC" 
      echo "Vous n'avez pas l'autorisation d'�criture dans $POLYBIN"
      echo "Contactez votre administrateur syst�me"
      exit 1;
else
   cp -f bin/* /usr/local/bin
   echo  "OK"
fi
echo -e  "Mise � jour de la base de donn�es des fichiers de teTeX : \c"
mktexlsr > /dev/null
echo  "OK"
