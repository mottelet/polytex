Distribution polytex2.0beta pour teTex/unix ou MikTeX/windows
----------------------------------------------------------

Pour la distribution unix voir le fichier README dans le
dossier unix. Pour la distribution windows voir le fichier
README.txt dans le dossier windows.

Les deux archives

polytex-install2.0beta.zip
polytex-install2.0beta.tar.gz

contiennent exactement la meme chose. Le site officiel
PolyTeX est en pr�paration, soyez patients, ca ne devrait
plus tarder.

La documentation (obsol�te) se trouve dans le dossier "doc".
Un exemple illustrant ce qu'il est possible de faire depuis la
version 1.5 se trouve dans le dossier "exemple1.5". Un exemple
de fichier utilisant les nouveaut�s de la version 2.0beta (sons,
vid�o, etc.) se trouve dans le dossier "exemple2.0beta".

Le dossier "template"
est un dossier mod�le � partir duquel vous pouvez produire votre propre
document.

Vos anciens documents peuvent etre compil�s avec la nouvelle version 2.0beta
en changeant "polytex" par "polytexbeta" dans le \documentstyle au debut
du document. 

St�phane Mottelet, le 1/11/2000

stephane.mottelet@utc.fr
