#!/bin/sh
#
# Shell-script d'installation de PolyTeXML pour UNIX/teTeX
#
# S. Mottelet, le 17/4/2002

if test -z $TEXMF;
   then echo -e  "Chemin du r�pertoire texmf de votre distribution teTeX :\c "
   read TEXMF
   if ! test -f $TEXMF/tex/latex/polytex/polyTeXMLmacros.sty;
      then echo "polyTeX n'est pas install� ou la version est trop ancienne !"
		echo "Veuillez installer une version >= 2.5 de polyTeX."
      exit 1;
   fi
fi

echo -e  "Repertoire d'installation de polyTeXML [/usr/local/polyTeXML] : \c"
read POLYTEXML
if test -z "$POLYTEXML";
   then POLYTEXML=/usr/local/polyTeXML
fi
echo -e  "Installation de polyTeXML dans $POLYBIN : \c"
if test ! -w $POLYTEXML;
      then echo "ECHEC" 
      echo "Vous n'avez pas l'autorisation d'�criture dans $POLYTEXML"
      echo "Contactez votre administrateur syst�me"
      exit 1;
else
   cp -r polyTeXML /usr/local/
   echo  "OK"
fi

echo -e  "Repertoire d'installation des fichiers de commande [/usr/local/bin] : \c"
read POLYBIN
if test -z "$POLYBIN";
   then POLYBIN=/usr/local/bin
fi
echo -e  "Installation des fichies de commande dans $POLYBIN : \c"
if test ! -w $POLYBIN;
      then echo "ECHEC" 
      echo "Vous n'avez pas l'autorisation d'�criture dans $POLYBIN"
      echo "Contactez votre administrateur syst�me"
      exit 1;
else
   cp -f polyTeXML/bin/* $POLYBIN
   echo  "OK"
fi
