#include <stdio.h>

main()
{
	unsigned char a='�';
	printf("%d\n",a);
}
